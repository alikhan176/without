# without login

pkg update

pkg upgrade

pkg install git

Pkg install python

pkg install python2

pip2 install requests

pip2 install mechanize

git clone https://github.com/BlackTiger-Error404/without.git

cd without

python2 Happy.py

PAS:03037335114
